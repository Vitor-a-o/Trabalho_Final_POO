
package dungeonfighter;

public class Barbaro extends Heroi{
    public Barbaro(String nome){
        super(10, 5, 8);
        super.setNome(nome);
    }
}
