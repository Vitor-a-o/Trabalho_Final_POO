
package dungeonfighter;

public class Guerreiro extends Heroi{
    public Guerreiro(String nome){
        super(10, 5, 8);
        super.setNome(nome);
    }
}
