
package dungeonfighter;

public abstract class Monstro extends Personagem {
    
    public Monstro(int ataque, int defesa, int saude){
        super(ataque, defesa, saude);
    }
    
}
