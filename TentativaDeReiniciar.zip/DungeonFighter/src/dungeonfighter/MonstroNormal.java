
package dungeonfighter;

public class MonstroNormal extends Monstro {
    public MonstroNormal(){
        super(5, 5, 10);
        super.setNome("Monstrinho");
    }
}
