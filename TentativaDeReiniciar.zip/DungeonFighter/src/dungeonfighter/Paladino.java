
package dungeonfighter;

public class Paladino extends Heroi {
    public Paladino(String nome){
        super(10, 5, 8);
        super.setNome(nome);
    } 
}
