/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dungeonfighter;

/**
 *
 * @author Duda
 */
public class Chefao extends Monstro {
    
    // os atributos do chefao precisam ser maiores que o do monstro normal!!!
    
    public Chefao(){
        super(6, 8, 30, "Boss");
    }
    
}
