/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dungeonfighterduda;

/**
 *
 * @author Duda
 */
public abstract class Monstro extends Personagem {
    
    public Monstro(int ataque, int defesa, int saude, String nome){
        super(ataque, defesa, saude, nome);
    }
    
}
