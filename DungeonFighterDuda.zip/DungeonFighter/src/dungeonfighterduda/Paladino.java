/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dungeonfighterduda;

/**
 *
 * @author Duda
 */
public class Paladino extends Heroi {
    public Paladino(){
        super(5, 8, 10, "Paladino");
    }
    
    /*
    public Paladino(int ataque, int defesa, int saude, String nome){
        super(ataque, defesa, saude, nome);
    }
    */
    
}
